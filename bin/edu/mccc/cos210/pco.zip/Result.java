package edu.mccc.cos210.pco;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Result extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Keeps the value of the coins. 
	 */
	private double value;
	
	/**
	 * Constructor. Gets the value from the calculator and uses it for the JFrame
	 */
	public Result(double d) {
		//creates calculator
		setValue(d);
		showResult(value);
	}
	public static void main(final String[] sa) {
		EventQueue.invokeLater(
				() -> new Result(20.05)
			);
	}
	/**
	 * Inspector in charge of returning the value
	 * @return The value of the coins
	 */
	public double getValue() {
		return value;
	}
	
	/**
	 * In charge of setting the value of the calculator
	 * @param value
	 */
	public void setValue(double value) {
		this.value = value;
	}
	
	/**
	 * Shows the result on a JFrame.
	 */
	public void showResult(double d) {
		JFrame jf = new JFrame("Result");
		JPanel jp = new JPanel();
		JLabel jl = new JLabel("the total value of the coins is " + String.valueOf(value));
		jl.setFont(new Font("Times New Roman",1,25));
		jp.setSize(1024, 768);
		jp.setLayout(new BorderLayout());
		jp.setBackground(Color.RED);
		jp.add(jl,BorderLayout.CENTER);
		jf.add(jp);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setSize(1024, 768);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
	}
	
	/**
	 * Called when the restart button is pressed
	 */
	public void returnHome() {
		//returns you to the home screen JFrame
	}
}
