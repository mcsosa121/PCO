package edu.mccc.cos210.pco;

public class PrestoChangeO {
	
	
	public static void main(String[] main) {
		openHomePage();
	}
	
	static void openHomePage() {
		HomeFrame homePage = new HomeFrame();
		homePage.setVisible(true);
	}
}
