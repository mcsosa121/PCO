package edu.mccc.cos210.pco;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.io.File;

import javax.imageio.ImageIO;


public class EdgeDetection {
    public BufferedImage detectEdge(BufferedImage src){
       //kernel for edge detection adding upto less than 1
       float edgeArr[]={0,-1,0,-1,4,-1,0,-1,0};
       //creating the convolution operator
       ConvolveOp edgeOp=new ConvolveOp(new Kernel(3,3,edgeArr),ConvolveOp.EDGE_NO_OP,null);
    	
       return edgeOp.filter(src, null);  //operating on image
    }
    
    public static void main(String[] args)throws Exception {
       EdgeDetection obj=new EdgeDetection();
       Color myWhite = new Color(66, 66, 255);
       int rgb = myWhite.getRGB();
       BufferedImage rc=ImageIO.read(new File("coin.jpg"));
       BufferedImage src=ImageIO.read(new File("dest_edge.jpg")),
       dest=obj.detectEdge(src);  //edge detection
       for(int i=0;i<3264;i++) {
    	   for(int j=0;j<2448;j++) {
    		   if(dest.getRGB(i, j)>=-15500000){
    			 System.out.println("X: "+i+", "+"Y: "+j +", RGB: "+dest.getRGB(i, j)); 
    			 rc.setRGB(i, j, rgb);
    		   }
    	   }
       }
      // System.out.println(dest.getRGB(1819, 1088));
       ImageIO.write(rc, "jpeg",new File("dest_edge3.jpg"));
    }
}
