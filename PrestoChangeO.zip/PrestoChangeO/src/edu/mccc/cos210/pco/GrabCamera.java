package edu.mccc.cos210.pco;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.RenderedImage;
import java.io.File;
import java.util.Iterator;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.media.Buffer;
import javax.media.CaptureDeviceInfo;
import javax.media.CaptureDeviceManager;
import javax.media.Format;
import javax.media.MediaLocator;
import javax.media.bean.playerbean.MediaPlayer;
import javax.media.control.FrameGrabbingControl;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;
import javax.media.util.BufferToImage;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GrabCamera extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private MediaPlayer mp = null;
	public GrabCamera() {
		super("Camera Image Grabber");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Component c = initFramework();
		add(c, BorderLayout.CENTER);
		JButton jb = new JButton("Capture");
		jb.addActionListener(this);
		add(jb, BorderLayout.SOUTH);
		setSize(1024, 768);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	public static void main(String[] sa) {
		EventQueue.invokeLater(
			() -> new GrabCamera()
		);
	}
	@SuppressWarnings("rawtypes")
	private Component initFramework() {
		CaptureDeviceInfo camera = createCamera();
		CaptureDeviceManager.addDevice(camera);
		Vector deviceInfoArray = CaptureDeviceManager.getDeviceList(null);
		Iterator it = deviceInfoArray.iterator();
		while (it.hasNext()) {
			CaptureDeviceInfo cdi = (CaptureDeviceInfo) it.next();
			System.out.println(cdi.getName());
			Format[] fa = cdi.getFormats();
			for (Format f : fa) {
				System.out.println("\t" + f.toString());
			}
		}
		this.mp = new MediaPlayer();
		this.mp.setMediaLocator(camera.getLocator());
		this.mp.start();
		return this.mp;
	}
	private CaptureDeviceInfo createCamera() {
		Format[] fa = {
			new YUVFormat(
				new Dimension(640, 480),
				614400,
				byte[].class,
				15.0f,
				32,
				1280,
				1280,
				0,
				1,
				3
			)
		};
		CaptureDeviceInfo device = new CaptureDeviceInfo(
			"vfw:Microsoft WDM Image Capture (Win32):0",
			new MediaLocator("vfw://0"),
			fa
		);
		return device;
	}
	@Override
	public void actionPerformed(ActionEvent ae) {
		FrameGrabbingControl fgc = (FrameGrabbingControl) this.mp.
			getControl("javax.media.control.FrameGrabbingControl");
        Buffer buf = fgc.grabFrame();
        BufferToImage btoi = new BufferToImage((VideoFormat) buf.getFormat());
        Image img = btoi.createImage(buf);
        try {
			ImageIO.write((RenderedImage) img, "bmp", new File("./coins.bmp"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
 	}
}
