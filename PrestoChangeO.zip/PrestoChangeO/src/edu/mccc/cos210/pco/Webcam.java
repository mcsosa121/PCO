package edu.mccc.cos210.pco;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.util.Iterator;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.media.Buffer;
import javax.media.CaptureDeviceInfo;
import javax.media.CaptureDeviceManager;
import javax.media.Format;
import javax.media.MediaLocator;
import javax.media.bean.playerbean.MediaPlayer;
import javax.media.control.FrameGrabbingControl;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;
import javax.media.util.BufferToImage;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Webcam extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private MediaPlayer mp = null;
	BufferedImage src= null;
	private JFrame self;
	/**
	 * 
	 * @param sa The command line arguments
	 */
	public static void main(String[] sa) {
		EventQueue.invokeLater(
			() -> new Webcam()
		);	
	}
	/**
	 * Checks to see if there is a webcam available
	 * @throws Exception no webcam is found
	 */
	public boolean confirmWebcam() {
		boolean isthere = false;
		return isthere;
		
	}
	/**
	 * Opens the link to the webcam which allows its use in the JFrame
	 * 
	 */
	private Component openWebcam() {
		CaptureDeviceInfo camera = createCamera();
		CaptureDeviceManager.addDevice(camera);
		Vector deviceInfoArray = CaptureDeviceManager.getDeviceList(null);
		Iterator it = deviceInfoArray.iterator();
		while (it.hasNext()) {
			CaptureDeviceInfo cdi = (CaptureDeviceInfo) it.next();
			System.out.println(cdi.getName());
			Format[] fa = cdi.getFormats();
			for (Format f : fa) {
				System.out.println("\t" + f.toString());
			}
		}
		this.mp = new MediaPlayer();
		this.mp.setMediaLocator(camera.getLocator());
		this.mp.start();
		return this.mp;
	}
//	/**
//	 * Uses the webcam to take a picture
//	 */
//	public void takePicture() {
//		
//	}
//	/**
//	 * Makes sure the picture taken is correct
//	 * @return image data from webcam
//	 */
//	public void confirmPicture() {
//		
//	}
	/**
	 * Saves the image to a file
	 * @return new image file
	 */
	public void savePicture() {
		FrameGrabbingControl fgc = (FrameGrabbingControl) this.mp.
				getControl("javax.media.control.FrameGrabbingControl");
	        Buffer buf = fgc.grabFrame();
	        BufferToImage btoi = new BufferToImage((VideoFormat) buf.getFormat());
	        Image img = btoi.createImage(buf);
	        try {
				ImageIO.write((RenderedImage) img, "bmp", new File("./coins.bmp"));
				src = ImageIO.read(new File("./coins.bmp"));
			} catch (Exception ex) {
				ex.printStackTrace();
			}
	}
	/**
	 * 
	 * @return Jframe containing webcam image
	 */
	public Webcam() {
		super("Camera Image Grabber");
		self = this;
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Component c = openWebcam();
		add(c, BorderLayout.CENTER);
		JButton jb = new JButton("Capture");
		jb.addActionListener(this);
		add(jb, BorderLayout.SOUTH);
		setSize(1024, 768);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		savePicture();
		self.dispose();
		WebcamPreviewerFrame fp = new WebcamPreviewerFrame(src);
		fp.setVisible(true);
		
	}
	private CaptureDeviceInfo createCamera() {
		Format[] fa = {
			new YUVFormat(
				new Dimension(640, 480),
				614400,
				byte[].class,
				15.0f,
				32,
				1280,
				1280,
				0,
				1,
				3
			)
		};
		CaptureDeviceInfo device = new CaptureDeviceInfo(
			"vfw:Microsoft WDM Image Capture (Win32):0",
			new MediaLocator("vfw://0"),
			fa
		);
		return device;
	}
}
