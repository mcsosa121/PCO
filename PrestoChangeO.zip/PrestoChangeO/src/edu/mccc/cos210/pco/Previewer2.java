package edu.mccc.cos210.pco;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Previewer2 extends JFrame {
	private static final long serialVersionUID = 1L;
	private JButton jd = new JButton("Draw");
	private BufferedImage image = null;
	JPanel panel = new FilePreviewerPanel(LoadImage());

	public Previewer2() {
		super("Previewer2");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(1024, 768);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
		jd.addActionListener(
			ae -> {
				System.out.println("Placemarker");
			}
		);
		add(jd, BorderLayout.SOUTH);
		add(panel, BorderLayout.CENTER);
	}

	public BufferedImage LoadImage() {
	       try {
	           image = ImageIO.read(new File("dest_edge.jpg"));
	       } catch (IOException e) {
	       }
	       return image;
	    }
	
	
	
	/**
	 * Initializes previewer
	 * @param sa The command line arguments
	 */
	public static void main(String[] sa) {
		EventQueue.invokeLater(
				() -> new Previewer2()		
				
		);
	}
	/**
	 * @return JFrame that will contain preview of image
	 */
	

	/**
	 * @param url location of saved image
	 * @return jpanel containing image
	 * Loads up the image panel  onto the JFrame
	 */
	public void showImage(String url) {
		
	}
	/**
	 * Uses the preview window containing the image selected and
	 * draws border around the coins.
	 */
	public void drawOnCoin() {
		
		
	}
}
