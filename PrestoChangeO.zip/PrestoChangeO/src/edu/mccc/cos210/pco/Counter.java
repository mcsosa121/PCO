package edu.mccc.cos210.pco;

public class Counter {
	
	/**
	 * Keeps the count of the Pennies.
	 */
	private int countOfPennies;
	
	/**
	 * Keeps the count of the Nickels.
	 */
	private int countOfNickels;
	
	/**
	 * Keeps the count of the Dimes.
	 */
	private int countOfDimes;
	
	/**
	 * Keeps the count of the Quarters.
	 */
	private int countOfQuarters;
	
	/**
	 * Constructer. Can't think of a purpose
	 */
	public Counter() {
		//this might not be needed
	}
	
	/**
	 * Called to count the found pennies. 
	 */
	public void countPennies() {
	}
	
	/**
	 * Called to count the found nickels. 
	 */
	public void countNickels() {
	}
	/**
	 * Called to count the found dimes. 
	 */
	
	public void countDimes() {
	}
	
	/**
	 * Called to count the found quarters. 
	 */
	public void countQuarters() {
	}
	
	/**
	 * Inspector in charge of the count of the pennies
	 * @return the count of the pennies
	 */
	public int getCountOfPennies() {
		return countOfPennies;
	}
	
	public void setCountOfPennies(int countOfPennies) {
		this.countOfPennies = countOfPennies;
	}
	
	/**
	 * Inspector in charge of the count of the nickels
	 * @return the count of the nickels
	 */
	public int getCountOfNickels() {
		return countOfNickels;
	}
	public void setCountOfNickels(int countOfNickels) {
		this.countOfNickels = countOfNickels;
	}
	
	/**
	 * Inspector in charge of the count of the dimes
	 * @return the count of the dimes
	 */
	public int getCountOfDimes() {
		return countOfDimes;
	}
	public void setCountOfDimes(int countOfDimes) {
		this.countOfDimes = countOfDimes;
	}
	
	/**
	 * Inspector in charge of the count of the quarters
	 * @return the count of the quarters
	 */
	public int getCountOfQuarters() {
		return countOfQuarters;
	}
	public void setCountOfQuarters(int countOfQuarters) {
		this.countOfQuarters = countOfQuarters;
	}
}
