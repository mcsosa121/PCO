package edu.mccc.cos210.pco;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
public class Previewer extends Component{  
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	BufferedImage img;
    public void paint(Graphics g) {
    	super.paint(g);
        g.drawImage(img, 0, 0, null);
        DrawCircle(g);    
        drawCircle(img,1, -1);
    }   
	public Previewer() {
       try {
           img = ImageIO.read(new File("Coins.jpg"));
       } catch (IOException e) {
       }
    } 
    public Dimension getPreferredSize() {
        if (img == null) {
             return new Dimension(100,100);
        } else {
           return new Dimension(img.getWidth(null), img.getHeight(null));
       }
    }
    public static void DrawCircle(Graphics g){
    	Graphics2D g2d = (Graphics2D) g.create();
    	g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(2.0f)); 
        g2d.drawOval(116, 67, 133, 133);    //Reference Coin
        Graphics2D g2d1 = (Graphics2D) g.create();
    	g2d1.setColor(Color.BLUE); 			//Dime
        g2d1.setStroke(new BasicStroke(2.0f));
        g2d1.drawOval(223, 274, 65, 65);   
        Graphics2D g2d2 = (Graphics2D) g.create();
    	g2d2.setColor(Color.BLUE); 			//Nickel
        g2d2.setStroke(new BasicStroke(2.0f));
        g2d2.drawOval(365, 170, 80, 80);   
        Graphics2D g2d3 = (Graphics2D) g.create();
    	g2d3.setColor(Color.BLUE); 			//Quart
        g2d3.setStroke(new BasicStroke(2.0f));
        g2d3.drawOval(355, 403, 92, 92);  
        Graphics2D g2d4 = (Graphics2D) g.create();
    	g2d4.setColor(Color.BLUE); 			//Penny
        g2d4.setStroke(new BasicStroke(2.0f));
        g2d4.drawOval(503, 318, 75, 75); 
    }
    static void
    drawCircle(Image image,int radius, float value)
    {
      int x, y;
      int l;
      int r2, y2;
      int y2_new;
      int ty;
      /* cos pi/4 = 185363 / 2^18 (approx) */
      l = (radius * 185363) >> 18;
      /* At x=0, y=radius */
      y = radius;
      r2 = y2 = y * y;
      ty = (2 * y) - 1;
      y2_new = r2 + 3;

      for (x = 0; x <= l; x++) {
        y2_new -= (2 * x) - 3;

        if ((y2 - y2_new) >= ty) {
          y2 -= ty;
          y -= 1;
          ty -= 2;
        }

        imageSetpixel(image, x, y, value);
        imageSetpixel(image, x, -y, value);
        imageSetpixel(image, -x, y, value);
        imageSetpixel(image, -x, -y, value);

        imageSetpixel(image, y, x, value);
        imageSetpixel(image, y, -x, value);
        imageSetpixel(image, -y, x, value);
        imageSetpixel(image, -y, -x, value);
      }
    }
	private static void imageSetpixel(Image image, int x, int y, float value) {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
        JFrame f = new JFrame("Previewer");
        f.add(new Previewer(),BorderLayout.CENTER);
        f.pack();
        f.setVisible(true);
    }
	
}



