package edu.mccc.cos210.pco;

import java.awt.image.BufferedImage;

@SuppressWarnings("unused")
public class Finder {
	
	/**
	 * The image. What we need to find the coins in. Not sure if properly set up
	 */
	private BufferedImage bi;
	
	/**
	 * used to store the size of the key circle
	 */
	private double sizeOfKeyCircle;
	
	/**
	 * Gets size of the identifier. That is later used to then be able to find and identify the coins
	 */
	public double findKeyCircle(){
		return 0.0;
	}
	
	/**
	 * Algorithm to locate the pennies
	 */
	public void findPennies() {
		double sizeOfPennies = sizeOfKeyCircle;//do something to get size of penny relative to key circle
	}
	
	/**
	 * Algorithm to locate the nickels
	 */
	public void findNickles() {
		
	}
	
	/**
	 * Algorithm to locate the dimes
	 */
	public void findDimes() {
		
	}
	
	/**
	 * Algorithm to locate the quarters
	 */
	public void findQuarters() {
		
	}
}
