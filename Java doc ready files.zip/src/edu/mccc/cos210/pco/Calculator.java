package edu.mccc.cos210.pco;

public class Calculator {
	
	/**
	 * Keeps the count of the Pennies.
	 */
	private int countOfPennies;
	
	/**
	 * Keeps the count of the Nickels.
	 */
	private int countOfNickels;
	
	/**
	 * Keeps the count of the Dimes.
	 */
	private int countOfDimes;
	
	/**
	 * Keeps the count of the Quarters.
	 */
	private int countOfQuarters;
	
	/**
	 * Keeps the value of the coins. 
	 */
	private double value;
	
	/**
	 * Constructor. Creates the Calculator and gets the values
	 */
	public Calculator() {
		setCountOfPennies(0/*int from Counter.getCountOfPennies*/);
		setCountOfNickels(0/*int from Counter.getCountOfNickels*/);
		setCountOfDimes(0/*int from Counter.getCountOfDimes*/);
		setCountOfQuarters(0/*int from Counter.getCountOfQuarters*/);
		setValue(0.0);
	}
	
	/**
	 * The method you call to calculate the value of the coins.
	 */
	public double calculate() {
		value = (0.01 * getCountOfPennies());
		value = value + (0.05 * getCountOfNickels());
		value = value + (0.10 * getCountOfDimes());
		value = value + (0.25 * getCountOfQuarters());
		return value;
	}
	
	/**
	 * Inspector in charge of the count of the pennies
	 * @return the count of the pennies
	 */
	public int getCountOfPennies() {
		return countOfPennies;
	}
	public void setCountOfPennies(int countOfPennies) {
		this.countOfPennies = countOfPennies;
	}
	
	/**
	 * Inspector in charge of the count of the nickels
	 * @return the count of the nickels
	 */
	public int getCountOfNickels() {
		return countOfNickels;
	}
	public void setCountOfNickels(int countOfNickels) {
		this.countOfNickels = countOfNickels;
	}
	
	/**
	 * Inspector in charge of the count of the dimes
	 * @return the count of the dimes
	 */
	public int getCountOfDimes() {
		return countOfDimes;
	}
	
	public void setCountOfDimes(int countOfDimes) {
		this.countOfDimes = countOfDimes;
	}
	
	/**
	 * Inspector in charge of the count of the quarters
	 * @return the count of the quarters
	 */
	public int getCountOfQuarters() {
		return countOfQuarters;
	}
	
	public void setCountOfQuarters(int countOfQuarters) {
		this.countOfQuarters = countOfQuarters;
	}
	
	/**
	 * Inspector in charge of returning the value
	 * @return The value of the coins
	 */
	public double getValue() {
		return value;
	}
	
	/**
	 * In charge of setting the value of the calculator
	 * @param value
	 */
	public void setValue(double value) {
		this.value = value;
	}
	
}
