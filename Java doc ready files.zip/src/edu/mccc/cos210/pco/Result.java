package edu.mccc.cos210.pco;

import javax.swing.JFrame;

public class Result extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Keeps the value of the coins. 
	 */
	private double value;
	
	/**
	 * Constructor. Gets the value from the calculator and uses it for the JFrame
	 */
	public Result() {
		setValue(0.0/*calculator.calculate*/);
		showResult(value);
	}

	/**
	 * Inspector in charge of returning the value
	 * @return The value of the coins
	 */
	public double getValue() {
		return value;
	}
	
	/**
	 * In charge of setting the value of the calculator
	 * @param value
	 */
	public void setValue(double value) {
		this.value = value;
	}
	
	/**
	 * Shows the result on a JFrame.
	 */
	public void showResult(double d) {
		
	}
	
	/**
	 * Called when the restart button is pressed
	 */
	public void returnHome() {
		//returns you to the home screen JFrame
	}
}
